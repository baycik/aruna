<?php
// Heading
$_['heading_title'] = 'So Super Category';

// Text
$_['text_tax']      = 'Налог:';
$_['text_date']      = 'Дата: ';
// So super category
$_['all_ready_label'] 	= 'Готово';
$_['load_more_label'] 	= 'Ещё';
$_['value_price'] 		= 'Цена';
$_['value_name'] 		= 'Название';
$_['value_model'] 		= 'Артикул';
$_['value_quantity'] 	= 'Количество';
$_['value_rating'] 		= 'Популярные';
$_['value_sort_add'] 	= 'По дате добавления';
$_['value_date_add'] 	= 'Новые поступления';
$_['value_sale'] 		= 'Хиты продаж';
$_['text_noitem']      = 'Нет данных для показа!';
$_['text_sale']      	= 'Распродажа';
$_['text_new']      	= 'Новинки';
$_['button_cart']      	= 'Добавить в корзину';
$_['text_view_all']      	= 'Показать всё';