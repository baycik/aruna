<?php
// Heading
$_['heading_title'] = 'Последние блоги';

$_['text_readmore'] = 'Прочитайте больше';
