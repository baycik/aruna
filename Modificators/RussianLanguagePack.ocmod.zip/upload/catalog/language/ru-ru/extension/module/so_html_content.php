<?php
// Heading
$_['heading_title'] = 'So Html Content';

// Text
$_['text_tax']      		= 'Налог:';
$_['text_noproduct']      	= 'Нет данных для показа!';
$_['text_sale']      	= 'Распродажа';
$_['text_new']      	= 'Новинка';