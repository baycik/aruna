<?php
// Heading
$_['heading_title'] = 'Сделки';

// Text
$_['text_tax']      		= 'Налог:';
$_['text_noitem']      		= 'Нет данных для показа!';
$_['text_sale']      		= 'Распродажа';
$_['text_new']      		= 'Новинка';
$_['text_time_left']      		= '<span>Спешите!</span> Предложение действительно до:';

$_['text_Day']      		= 'День';
$_['text_Hour']      		= 'Час';
$_['text_Min']      		= 'Минута';
$_['text_Sec']      		= 'Секунд';
$_['text_Days']      		= 'Дней';
$_['text_Hours']      		= 'Часов';
$_['text_Mins']      		= 'Минут';
$_['text_Secs']      		= 'Секунд';

$_['text_viewall']       = 'Показать всё';
$_['text_available']    = 'Доступно:';
$_['text_sold']       	= 'Продано:';
