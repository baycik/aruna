<?php
// Text
$_['text_more_category']           = "Больше категорий";
$_['text_close_category']          = "Закрыть категории";
