<?php
// Heading 

// Text
$_['text_search_article']	= 'Поиск по статье:';

// Buttons
$_['button_search']			= 'Поиск';