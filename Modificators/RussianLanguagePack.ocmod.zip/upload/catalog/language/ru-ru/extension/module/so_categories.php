<?php
// Heading
$_['heading_title'] = 'So listing tabs';

// Text
$_['text_nocate']   = 'Нет категорий!';
$_['text_noitem']   = 'Перейти в категорию';

$_['text_morecate'] = 'Больше категорий';