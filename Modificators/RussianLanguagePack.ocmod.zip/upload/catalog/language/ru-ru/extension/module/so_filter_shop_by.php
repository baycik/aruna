<?php
// Heading
$_['heading_title'] = 'So Filter Shop By';

// Text
$_['text_tax']      		= 'Налог:';
$_['text_noproduct']      	= 'Нет данных для показа!';
$_['text_sale']      		= 'Распродажа';
$_['text_new']      		= 'Новинка';

$_['text_search']      		= 'Поиск';
$_['text_price']      		= 'Цена';
$_['text_reset_all']      	= 'Сбросить';
$_['text_manufacturer']     = 'Производитель';
$_['text_subcategory']     	= 'Подкатегория';
$_['button_cart']     		= 'Добавить в корзину';
$_['button_compare']       = 'Сравнить';
$_['button_wishlist']       = 'Избранное';
$_['button_quickview']       = 'Быстрый просмотр';
