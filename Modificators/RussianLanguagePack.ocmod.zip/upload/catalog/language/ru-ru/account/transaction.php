<?php
// Heading
$_['heading_title']      = 'История платежей';

// Column
$_['column_date_added']  = 'Добавлено';
$_['column_description'] = 'Описание';
$_['column_amount']      = 'Сумма (%s)';

// Text
$_['text_account']       = 'Личный Кабинет';
$_['text_transaction']   = 'Мои платежи';
$_['text_total']         = 'Мой текущий баланс';
$_['text_empty']         = 'У Вас пока не было платежей!';

