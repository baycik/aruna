<?php
// Text
$_['text_footer'] 	= '<hr><a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Все права защищены.<br> <a href="http://opencart3x.ru" target="_blank">Русская версия OpenCart 3 - модули и шаблоны</a>';
$_['text_version'] 	= 'Version %s';

