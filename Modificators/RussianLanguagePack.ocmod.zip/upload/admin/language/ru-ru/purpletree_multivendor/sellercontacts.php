<?php		
// Heading		
$_['heading_title']         	=	"Запросы клиентов";
		
//text		
$_['text_heading'] 	=	"Запросы клиентов";
$_['text_email']			=	"Эл. почта клиента";
$_['text_description']			=	"Сообщение";
$_['text_customer_name']          	=	"Имя Клиента";
$_['text_date_added']          	=	"Дата добавления";
$_['text_confirm']          	=	"В случае чего, вы готовы понести наказание за содеянное?";
$_['text_seller_name']          	=	"Имя продавца";


$_['text_seller_to_customer'] = "От продавца клиенту";
$_['text_customer_to_seller'] = "От клиента продавцу";
		
$_['column_action']          	=	"Действие";
		
$_['text_view']          	=	"Вид";
$_['button_view']          	=	"Вид";
$_['button_delete']          	=	"Удалить";
$_['button_filter']          	=	"Фильтр";
		
$_['text_list']          	=	"Список запросов";
$_['text_no_results']          	=	"Нет доступных запросов";
		
$_['text_empty_result'] 	=	"Для этого продавца нет никаких запросов";
$_['text_delete_success'] 	=	"Запрос успешно удален";
		
//button		
		
$_['button_continue'] 	=	"Продолжить";