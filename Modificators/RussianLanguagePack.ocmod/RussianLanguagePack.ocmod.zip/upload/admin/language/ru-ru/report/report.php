<?php
// Heading
$_['heading_title'] = 'Отчеты';

// Text
$_['text_success']  = 'Вы успешно изменили отчеты!';
$_['text_list']     = 'Список';
$_['text_type']     = 'Выберите тип отчета';
$_['text_filter']   = 'Фильтр';