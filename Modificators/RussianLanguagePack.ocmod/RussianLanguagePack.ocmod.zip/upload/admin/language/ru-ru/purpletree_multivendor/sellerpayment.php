<?php 		
$_['heading_title']			=	"Платежи";
		
//text		
$_['text_list']			=	"Список платежей";
$_['text_payment']			=	"Платежи";
$_['text_trnasaction']			=	"Идентификатор транзакции";
$_['text_amount']			=	"Сумма";
$_['text_payment_mode']			=	"Режим оплаты";
$_['text_status']			=	"Статус";
$_['text_payment_status']			=	"Статус платежа";
$_['text_created_at']			=	"Дата создания";
$_['text_no_results']			=	"У вас нет платежей!";
		
$_['entry_date_from']          	=	"Дата, с";
$_['entry_date_to']          	=	"Дата";
		
$_['button_filter'] 	=	"Фильтр";
?>		