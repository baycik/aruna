<?php 		
$_['heading_title']   	=	"Панель пулемета";
		
$_['text_edit']        	=	"Редактировать панель панели пульта Purpletree";
		
$_['text_extension']   	=	"Extensions";
$_['text_success']     	=	"Успех: у вас есть модифицированный модуль учетной записи!";
// Entry		
$_['entry_status']     	=	"Статус";
		
$_['text_sellerstore']   	=	"Информация о магазине";
$_['text_sellerproduct']   	=	"Управление товарами";
$_['text_sellerprofile']   	=	"Профиль продавца";
$_['text_sellerorder']   	=	"Заказы";
$_['text_sellercommission']   	=	"Комиссия";
$_['text_removeseller']   	=	"Удалить как продавец";
$_['text_becomeseller']   	=	"Стать продавцом";
$_['text_sellerview']   	=	"Просмотреть магазин";
$_['text_approval']   	=	"<b> Ожидание утверждения продавца </ b>";
$_['text_sellerpayment']   	=	"Платежи";
$_['text_sellerreview']   	=	"Мои отзывы";
		
?>		