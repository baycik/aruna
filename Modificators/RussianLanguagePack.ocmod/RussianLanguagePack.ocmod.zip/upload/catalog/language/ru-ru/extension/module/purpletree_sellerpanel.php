<?php		
$_['text_selleroption']   	=	"Панель продавца";
$_['text_dashboard']     = 'Аналитика';
$_['text_dashboard_icon']     = 'Панель управления';
$_['text_sellerstore']   	=	"Информация о магазине";
$_['text_sellerproduct']   	=	"Управление товарами";
$_['text_sellerprofile']   	=	"Профиль продавца";
$_['text_sellerorder']   	=	"Заказы";
$_['text_sellercommission']   	=	"Комиссия";
$_['text_removeseller']   	=	"Удалить профиль магазина";
$_['text_becomeseller']   	=	"Стать продавцом";
$_['text_sellerview']   	=	"Страница магазина";
$_['text_approval']   	=	"<b> Ожидание подтверждения администрации </ b>";
$_['text_sellerpayment']   	=	"Платежи";
$_['text_sellerreview']   	=	"Отзывы";
$_['text_sellerenquiry']   	=	"Запросы";
$_['text_downloads']   = "Управление загрузками";
$_['text_bulkproductupload']     = "Загрузка массового продукта";
$_['text_shipping']              = "Тарифы на доставку";

$_['text_subscription']              = "План подписки";
$_['text_subscriptions']              = "Счет-фактура";
$_['text_blog_post']             	     = 'Блог';
$_['text_blog_comment']              	 = 'Комментарии к блогу';
$_['text_commissioninvoice']   = 'Счета-фактуры комиссии';
?>		