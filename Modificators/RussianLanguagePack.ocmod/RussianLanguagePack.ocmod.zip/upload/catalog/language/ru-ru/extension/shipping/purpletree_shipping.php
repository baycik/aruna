<?php		
// Text		
$_['text_title']       	=	"Плата за доставку";