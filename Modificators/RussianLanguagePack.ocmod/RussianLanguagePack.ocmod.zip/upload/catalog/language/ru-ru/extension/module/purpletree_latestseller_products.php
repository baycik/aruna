<?php
// Heading
$_['heading_title'] = 'Последние продукты продавца';

// Text
$_['text_tax']      = 'Ex Tax:';