<?php
// Heading
//
$_['heading_title'] = 'Войти или зарегистрироваться';

$_['text_colregister'] = '<h2>Впервые здесь?</h2><p class="note-reg">Регистрация - это просто!</p>
                            <ul class="list-log">
                                <li>Быстрое оформление заказа</li>
                                <li>Возможность сохранять несколько адресов доставки</li>
                                <li>Просмотр и отслеживание заказов</li>
                            </ul>';

$_['text_create_account']	= 'Создать учетную запись';

$_['text_forgot_password']	= 'Забыли пароль?';

$_['text_title_popuplogin']	= 'Войти или зарегистрироваться';

$_['text_title_login_with_social']	= 'Войти с помощью социальных сетей';