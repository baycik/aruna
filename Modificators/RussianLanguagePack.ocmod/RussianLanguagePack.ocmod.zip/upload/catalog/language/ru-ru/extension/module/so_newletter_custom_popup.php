<?php
// Text
$_['input_check']           = "Больше не показывать это окно";
$_['label_email']           = "Введите свой емаил";
$_['newsletter_placeholder']= "Ваш емаил адрес...";
$_['newsletter_button']     = "Подпишитесь";
$_['text_email_require']     = "Емаил необходим";