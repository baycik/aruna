<?php

$_['error_name'] = "Введите имя.";
$_['error_email'] = "Введите email.";
$_['error_number'] = "Введите контактный телефон.";
$_['error_country'] = "Введите страну.";
$_['error_message'] = "Введите ваш вопрос.";

$_['text_success'] = "Спасибо за запрос.";
$_['text_email_not_sent'] = "Не получилось отправить Email.";

$_['text_subject'] = 'Вам перезвонят за %s';