<?php
// Heading
$_['heading_title'] = 'So categories slider';

// Text
$_['text_tax']      	= 'Налог:';
$_['text_noitem']      	= 'Нет данных для показа!';
$_['text_sale']      	= 'Распродажа';
$_['text_new']      	= 'Новинка';

$_['text_viewall']       = 'Показать всё';