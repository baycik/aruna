<?php
// Heading

$_['text_latest']  		= 'Последнее'; 
$_['text_comment']     	= ' Комментарий';
$_['text_comments']    	= ' Комментариев';
$_['text_view']        	= ' Просмотр';
$_['text_views']       	= ' Просмотров';
// Text
$_['text_none_author'] 	= 'Нет автора';
$_['text_tax']      	= 'Налог:';
$_['text_noitem']      	= 'Нет данных для показа!';
$_['text_no_database'] 	= 'Missing Database Tables for this Extension, Please Install "Simple Blog" Now!';