<?php
// Heading
$_['heading_title'] = 'Рекомендуемые магазины продавца';

// Text
$_['text_tax']      = 'Ex Tax:';