<?php

// Heading 

$_['text_date_format']		= '<b>д</b> М';

$_['text_popular_all']		= 'Популярные статьи';
$_['text_latest_all']		= 'Последние статьи';

$_['text_no_result']		= 'Ничего не найдено!';
$_['text_comments']		= '&nbsp;комментариев';
$_['text_comment']		= '&nbsp;комментарий';
$_['show_all_text']		= 'Показать всё';
