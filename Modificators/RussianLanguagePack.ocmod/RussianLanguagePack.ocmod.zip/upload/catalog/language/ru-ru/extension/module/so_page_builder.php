<?php
// Heading
//$_['heading_title'] = 'So Page builder';

// Text
$_['text_tax']      		= 'Налог:';
$_['text_noproduct']      	= 'Нет данных для показа!';

$_['shortcode_email']   			= 'Email';
$_['shortcode_email_desc']= 'Введите свой емаил чтобы полуить сообщение.';
$_['shortcode_email_validation']   	= 'Email необходим';
$_['shortcode_email_validation_']	= 'Введите пожалуйста верный емаил адрес';
$_['shortcode_name']   				= 'Имя';
$_['shortcode_name_desc']	= 'Введите имя которое будет отображаться в заголовке.';
$_['shortcode_name_validation']   	= 'Имя необходимо';
$_['shortcode_message']   			= 'Сообщение';
$_['shortcode_message_validation']  = 'Сообщение необходимо';
$_['shortcode_subject']   			= 'Тема';
$_['shortcode_subject_desc']		= 'Если вы выбрали да то укажите поле в котором указанна тема.';
$_['shortcode_subject_validation']  = 'Тема необходима';
$_['shortcode_send_success']  		= 'Ваше сообщение успешно было отправлено';
$_['shortcode_send_error']  		= 'Ошибка сервера';
$_['shortcode_carousel_not_item_desc']= 'Содержание для карусели не найдено, проверьте настройки.';