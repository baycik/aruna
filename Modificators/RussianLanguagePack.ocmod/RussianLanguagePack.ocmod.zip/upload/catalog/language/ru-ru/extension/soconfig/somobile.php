<?php
// Text
$_['text_home']          = 'Главная';
$_['text_shopping_cart'] = 'Корзина покупок';
$_['text_account']       = 'Моя учетная запись';
$_['text_register']      = 'Регистрация';
$_['text_login']         = 'Вход';
$_['text_logout']        = 'Выход';
$_['text_checkout']      = 'Оформление заказа';
$_['text_search']        = 'Поиск';
$_['text_cart']        = 'Корзина';
$_['text_all']           = 'Показать всё';
$_['text_more']       = 'Ещё';
$_['text_language']       = 'Языки';
$_['text_currency']       = 'Валюта';
$_['text_compare']       = 'Сравнение';
$_['text_itemcount']     = '<span class="items_cart">%s </span>';

$_['text_needhelp']      = 'Нужна помощь';
$_['text_emailus']       = 'Напишите нам';
$_['text_morecategory']       = 'Больше категорий';