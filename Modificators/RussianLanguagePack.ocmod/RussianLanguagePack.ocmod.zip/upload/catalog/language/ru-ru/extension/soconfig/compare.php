<?php
// Heading  
//$_['heading_title']          = 'SOthemes Compare';

// Text
$_['text_title']             = 'Товары для сравнения добавлены';
$_['text_thumb']             = '<img src="%s" alt="" />';
$_['text_success']           = 'Поздравляем: вы добавили <a href="%s">%s</a> в список <a href="%s">для сравнения</a>!';
$_['text_warning']           = 'Максимальное количество товаров для сравнения - 4. Первый добавленный товар был удален.';
$_['text_exists']            = 'Некоторые товары уже добавлены в список';

$_['text_items']             = '%s';
$_['text_compare']   	   	 = 'Сравнить (%s)';
$_['text_failure']           = 'Неудача';
// Error
$_['error_required']         = 'Требуется %s !';	

?>