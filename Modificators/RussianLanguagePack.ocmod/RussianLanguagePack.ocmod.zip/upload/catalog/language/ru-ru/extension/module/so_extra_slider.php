<?php
// Heading
$_['heading_title'] = 'So Extra Slider';

// Text
$_['text_tax']      		= 'Налог:';
$_['text_noproduct']      	= $_['heading_title'].': Нет данных для показа!';
$_['text_noitem']      	=  $_['heading_title'].': Нет данных для показа!';
$_['text_sale']      	= 'Распродажа';
$_['text_new']      	= 'Новинка';