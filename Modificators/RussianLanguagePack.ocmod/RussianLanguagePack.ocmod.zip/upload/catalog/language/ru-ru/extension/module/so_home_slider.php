<?php
// Heading
$_['heading_title'] = 'So home slider';

// Text
$_['text_tax']      = 'Налог:';
$_['text_noitem']      = $_['heading_title'].': Нет данных для показа!';