<?php
// Heading
$_['heading_title'] = 'So Popular Tabs';

// Messages
$_['text_notags']  		= 'Нет доступных меток';