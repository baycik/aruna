<?php
// Heading
$_['heading_title'] = 'Рекомендуемые товары этого магазина';

// Text
$_['text_tax']      = 'Налог:';