<?php		
// Text		
$_['text_heading'] 			=	"Продавцы";
$_['text_refine']       	=	"Поиск";
$_['text_product']      	=	"Товары";
$_['text_sellercontact']	=	"Связаться с продавцом";
$_['text_empty']        	=	"Для листинга нет продавцов.";
$_['text_sort']         	=	"Сортировать по:";
$_['text_name_asc']     	=	"Имя (A - Z)";
$_['text_name_desc']    	=	"Имя (Z - A)";
$_['text_limit']        	=	"Показать:";