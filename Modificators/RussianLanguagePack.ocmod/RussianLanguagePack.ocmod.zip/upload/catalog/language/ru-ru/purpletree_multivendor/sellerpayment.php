<?php 		
$_['heading_title']			=	"Платежи";
		
//text		
$_['text_payment']			=	"Платежи";
$_['text_trnasaction']			=	"Идентификатор Платежи";
$_['text_amount']			=	"Сумма";
$_['text_payment_mode']			=	"Режим оплаты";
$_['text_status']			=	"Статус";
$_['text_created_at']			=	"Дата создания";
$_['text_empty']			=	"У вас нет платежей!";
		
$_['entry_date_from']          	=	"Дата, с";
$_['entry_date_to']          	=	"Дата";
		
$_['button_filter'] 	=	"Фильтр";
?>		