<?php 		
$_['heading_title']			=	"Комиссия";
		
//text		
$_['text_commission']			=	"Комиссия";
$_['text_total_sale']			=	"Общая распродажа";
$_['text_total_commission']			=	"Общая комиссия";
$_['text_recvd_amt']			=	"Общая полученная сумма";
$_['text_pending_amt']			=	"Общая ожидаемая сумма";
$_['text_order_id']			=	"№";
$_['text_product_id']			=	"Название продукция а";
$_['text_product_price']			=	"Цена товара";
$_['text_status']			=	"Статус";
$_['text_created_at']			=	"Дата создания";
$_['text_empty']			=	"Комиссия ещё не была установлена!";
$_['entry_date_from']          	=	"Начало периода";
$_['entry_date_to']          	=	"Окончание периода";
		
$_['button_filter'] 	=	"Фильтр";
?>		