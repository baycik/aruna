<?php
// Quickview
$_['button_detail'] 		  = 'Детали';
$_['text_category_stock_quantity']  = 'Поторопитесь! осталось всего  %s товар(ов) !';

