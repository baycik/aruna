<?php
// Heading
$_['heading_title']      = 'Бонусные баллы';

// Column
$_['column_date_added']  = 'Добавлено';
$_['column_description'] = 'Описание';
$_['column_points']      = 'Бонусные баллы';

// Text
$_['text_account']       = 'Личный Кабинет';
$_['text_reward']        = 'Бонусные баллы';
$_['text_total']         = 'Накоплено бонусных баллов';
$_['text_empty']         = 'У Вас нет бонусных балов!';

