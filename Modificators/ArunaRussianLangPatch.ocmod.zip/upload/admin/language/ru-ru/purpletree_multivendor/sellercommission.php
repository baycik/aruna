<?php 		
$_['heading_title']			=	"Комиссия";
		
//text		
$_['text_commission']			=	"Комиссия";
$_['text_total_sale']			=	"Общая распродажа";
$_['text_total_commission']			=	"Общая комиссия";
$_['text_recvd_amt']			=	"Общая полученная сумма";
$_['text_pending_amt']			=	"Общая ожидаемая сумма";
$_['text_order_id']			=	"№";
$_['text_product_id']			=	"Название";
$_['text_product_price']			=	"Цена";
$_['text_status']			=	"Статус";
$_['text_created_at']			=	"Дата создания";
$_['text_list']			=	"Список комиссий";
$_['text_empty']			=	"Комиссия не установлена!";
		
$_['entry_date_from']          	=	"Период начала";
$_['entry_date_to']          	=	"Период окончания";
		
$_['button_filter'] 	=	"Фильтр";

$_['text_commission_percent']		= 'Комиссия';
$_['generate_invoice']		= 'Создать счет-фактуру';
$_['text_commission_fixed']		= 'Фиксированная комиссия';
$_['text_commission_shipping']		= 'Комиссия по доставке';

$_['entry_store']          = 'Магазин';
$_['entry_select_store']          = 'Выбрать магазин';

$_['success_message'] = 'Счет выполнен успешно';
$_['help_store'] = 'Примечание. Выберите хранилище для создания счета-фактуры.';
$_['help_Invoice'] = 'Счет уже сгенерирован';
?>		