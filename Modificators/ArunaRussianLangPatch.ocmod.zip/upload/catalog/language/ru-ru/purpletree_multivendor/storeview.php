<?php		
// Heading		
$_['heading_title']         	=	"Просмотр магазина";
		
//text		
		
$_['text_dashboard']			=	"Панель";
$_['text_storeview']			=	"Просмотр магазина";
$_['text_returnpolicy']			=	"Возврат";
$_['text_shippingpolicy']			=	"Политика доставки";
$_['text_empty']        	=	" В магазине этого продавца нет товаров ";
$_['text_error']        	=	" Store not found ";
$_['text_quantity']     	=	"Количество";
$_['text_manufacturer'] 	=	"Бренд:";
$_['text_model']        	=	"Код продукта:";
$_['text_points']       	=	"Бонусные баллы";
$_['text_price']        	=	"Цена:";
$_['text_tax']          	=	"Ex Tax:";
$_['text_compare']      	=	"Сравнение продуктов (% s)";
$_['text_sort']         	=	"Сортировать по:";
$_['text_default']      	=	"По умолчанию";
$_['text_name_asc']     	=	"Имя (A - Z)";
$_['text_name_desc']    	=	"Имя (Z - A)";
$_['text_price_asc']    	=	"Цена (низкая & высокая)";
$_['text_price_desc']   	=	"Цена (Высокий & Низкий)";
$_['text_rating_asc']   	=	"Рейтинг (самый низкий)";
$_['text_rating_desc']  	=	"Рейтинг (максимум)";
$_['text_model_asc']    	=	"Модель (A - Z)";
$_['text_model_desc']   	=	"Модель (Z - A)";
$_['text_limit']        	=	"Показать:";
$_['text_aboutstore']        	=	"О магазине";
$_['text_sellerreview']        	=	"Отзывы";
$_['text_sellercontact']			=	"Связаться с продавцом";
$_['text_products_categories'] 	=	"Категории";
$_['text_remove_account_success'] 	=	"Ваша учетная запись успешно удалена.!";
