<?php

$_['text_history']			= 'История';
$_['text_shopping_cart']	= 'Корзина покупок';
$_['text_register']			= 'Регистрация';
$_['text_account']			= 'Учетная запись';
$_['text_download']			= 'Скачать';
$_['text_login']			= 'Вход';
$_['text_recent_products']	= 'Показать просмотренные товары';
$_['text_my_account']		= 'Моя учетная запись';
$_['text_new']				= 'Новинка';
$_['text_items_product']	= 'Всего <span class="text-color">%s товар(ов)</span> in your cart';
$_['text_items']     	    = '<span class="items_cart">%s</span><span class="items_cart2"> товар(ов)</span><span class="items_carts"> - %s </span> ';
$_['button_cart']			= 'Добавить в корзину';
$_['text_search']			= 'Поиск';
$_['text_all_categories']	= 'Все категории';
$_['text_head_categories']	= 'Категории';
$_['text_head_cart']		= 'Корзина';
$_['text_head_account']		= 'Учетная запись';
$_['text_head_search']		= 'Поиск';
$_['text_head_recent_view']	= 'Просмотренные';
$_['text_head_gotop']		= 'Наверх';
$_['text_empty']            = 'ваша корзина пуста!';
$_['text_no_content']       = 'Пусто!';