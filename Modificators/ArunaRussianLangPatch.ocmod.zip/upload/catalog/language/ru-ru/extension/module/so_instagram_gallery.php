<?php


$_['text_noproduct']      	= ' Нет данных для показа!';
