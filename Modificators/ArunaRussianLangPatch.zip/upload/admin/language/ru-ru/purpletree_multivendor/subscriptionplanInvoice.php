<?php
$_['heading_title']               = 'Выставленный счет';

//text
$_['text_invoice']                 = 'Выставленный счет';
$_['text_invoice_details']         = 'Сведения о счете-фактуре';
$_['text_admin_store_name']        = 'Имя магазина администратора';
$_['text_address']                 = 'Адрес';
$_['text_telephone']               = 'телефон';
$_['text_email']                   = 'Эл. адрес';
$_['text_website']                 = 'Веб-сайт';
$_['text_seller_store_name']       = 'Имя Магазина Магазина';
$_['text_plan_details']            = 'Информация о плане';
$_['text_start_date']              = 'Начальная дата';
$_['text_end_date']              = 'Дата окончания';
$_['text_created_date']            = 'Дата создания:';
$_['text_joining_fee']             = 'Вступительный взнос';
$_['text_subscription_price']      = 'Цена подписки';
$_['text_invoice_id']              = 'Invoice Number:';
$_['text_payment_mode']            = 'Режим оплаты';
$_['text_status']                  = 'Положение дел';
$_['text_transaction_id']          = 'ID транзакции';
$_['text_payment_date']            = 'Дата платежа';
$_['text_comment']                 = 'Комментарий';
$_['text_grand_total']             = 'Общая сумма';
$_['text_offline_payment_form_invoice_id']    = 'Автономная платежная форма для идентификатора счета-фактуры';



