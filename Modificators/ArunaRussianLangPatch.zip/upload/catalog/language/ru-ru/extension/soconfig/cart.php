<?php
// Heading  
//$_['heading_title']          = 'SOthemes Cart';

// Text
$_['text_title']             = 'Товар добавлен в корзину';
$_['text_thumb']             = '<img src="%s" alt="" />';
$_['text_success']           = '<a href="%s">%s</a> теперь в вашей <a href="%s">корзине</a>!';
$_['text_items']     	     = '<span class="items_cart">%s</span><span class="items_cart2"> товар(ов)</span><span class="items_carts"> - %s </span> ';
$_['text_shop']  			  = 'Купить сейчас';
$_['text_shop_cart']		  = 'Моя корзина';
// Error
$_['error_required']         = 'Требуется %s !';	

?>