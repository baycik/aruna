<?php
// Text

$_['text_search']    	= 'Поиск...';

$_['text_category_all'] = 'Все категории';

$_['text_tax']      	= 'Налог';

$_['text_price']      	= 'Цена';

$_['button_cart']       = 'Добавить в корзину';

$_['button_wishlist']       = 'Добавить в избранное';

$_['button_compare']       = 'Добавить к сравнению';

$_['text_btn_search']    	= 'Поиск';
